package go.id.itbooks

data class BukuResponse(val books:List< Buku>)